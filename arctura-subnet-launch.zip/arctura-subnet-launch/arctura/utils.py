"""
arctura/utils.py

Utility functions for Merkle proof construction and energy tag resolution.
"""

import hashlib
import os


def build_merkle_proof(attestation_hash: str, depth: int = 3) -> list:
    """
    Build a simplified Merkle proof chain for an attestation hash.

    Phase 01: linear hash chain (depth = 3 nodes).
    Phase 02: full binary Merkle tree with sibling nodes.

    Returns a list of proof nodes, each with:
        - hash: str (SHA-256 hex)
        - direction: 'left' | 'right'
    """
    if not attestation_hash:
        return []

    proof = []
    current = attestation_hash

    for i in range(depth):
        sibling = hashlib.sha256(f"arctura-proof-salt-{i}-{current}".encode()).hexdigest()
        direction = "left" if i % 2 == 0 else "right"
        proof.append({"hash": sibling, "direction": direction})
        if direction == "left":
            current = hashlib.sha256((sibling + current).encode()).hexdigest()
        else:
            current = hashlib.sha256((current + sibling).encode()).hexdigest()

    return proof


def get_energy_tag() -> str:
    """
    Resolve the energy provenance tag for P5 Stewardship scoring.

    In Phase 01: reads from ARCTURA_ENERGY_TAG environment variable.
    In Phase 03: replaced by Stewardship Index API call with verified certificates.

    Valid values:
        'renewable_verified'  — backed by verified RECs or grid certificate
        'renewable_claimed'   — self-declared, unverified
        'unknown'             — not declared (default)
        'high_carbon'         — declared or detected high-carbon source
    """
    valid_tags = {"renewable_verified", "renewable_claimed", "unknown", "high_carbon"}
    tag = os.environ.get("ARCTURA_ENERGY_TAG", "unknown").strip().lower()
    return tag if tag in valid_tags else "unknown"
