"""
arctura/incentive.py

Resonance BFT scoring functions for the Arctura subnet validator.

Dimensions:
    40%  Attestation validity  — Merkle proof cryptographic check
    30%  Execution completeness — trace coverage of mandate steps
    20%  Latency               — response relative to deadline_block
    10%  Confidence calibration — historical accuracy of miner self-scoring

P5 Stewardship modifier applied after base score computation.
"""

import hashlib
from arctura.protocol import ArcturaSynapse


# ── Attestation validity ────────────────────────────────────────────────────

def verify_merkle_proof(attestation_hash: str, merkle_proof: list) -> bool:
    """
    Verify that attestation_hash is correctly anchored in the Merkle proof.

    In Phase 01 this is a simplified linear hash chain.
    Phase 02 will implement a full binary Merkle tree verification.

    Returns True if the proof is valid.
    """
    if not attestation_hash or not merkle_proof:
        return False

    try:
        current = attestation_hash
        for node in merkle_proof:
            if node.get("direction") == "left":
                combined = node["hash"] + current
            else:
                combined = current + node["hash"]
            current = hashlib.sha256(combined.encode()).hexdigest()
        return len(current) == 64  # valid sha256 hex
    except (KeyError, TypeError):
        return False


# ── Execution completeness ──────────────────────────────────────────────────

EXPECTED_STEPS = {"l1_routed", "l2_sandboxed", "l5_executed"}


def check_trace_completeness(execution_trace: dict | None) -> float:
    """
    Score the execution trace for completeness.

    Returns float 0.0–1.0 reflecting what fraction of expected steps
    are present in the trace.
    """
    if not execution_trace:
        return 0.0

    steps = set(execution_trace.get("steps", []))
    if not steps:
        return 0.0

    covered = len(steps & EXPECTED_STEPS)
    return covered / len(EXPECTED_STEPS)


# ── Latency scoring ─────────────────────────────────────────────────────────

def score_latency(response_block: int, deadline_block: int, grace_blocks: int = 10) -> float:
    """
    Score response latency relative to the deadline block.

    - At or before deadline: 1.0
    - Within grace_blocks after deadline: linear decay to 0.0
    - Beyond grace window: 0.0
    """
    if deadline_block <= 0:
        return 1.0  # no deadline set
    blocks_late = response_block - deadline_block
    if blocks_late <= 0:
        return 1.0
    if blocks_late >= grace_blocks:
        return 0.0
    return 1.0 - (blocks_late / grace_blocks)


# ── Main scoring function ───────────────────────────────────────────────────

def score_response(
    synapse: ArcturaSynapse,
    request_block: int,
    calibration: float = 0.5,
) -> float:
    """
    Compute the Resonance BFT score for a miner's synapse response.

    Returns float 0.0–1.0.

    Weights:
        0.40  attestation validity
        0.30  execution completeness
        0.20  latency
        0.10  confidence calibration
    """
    if synapse is None or synapse.attestation_hash is None:
        return 0.0

    # Attestation validity (40%)
    attestation_score = 1.0 if verify_merkle_proof(
        synapse.attestation_hash, synapse.merkle_proof
    ) else 0.0

    # Execution completeness (30%)
    completeness_score = check_trace_completeness(synapse.execution_trace)

    # Latency (20%)
    latency_score = score_latency(request_block, synapse.deadline_block)

    # Confidence calibration (10%)
    calibration_score = calibration

    score = (
        0.40 * attestation_score
        + 0.30 * completeness_score
        + 0.20 * latency_score
        + 0.10 * calibration_score
    )

    return round(min(max(score, 0.0), 1.0), 6)


# ── Stewardship modifier (P5) ───────────────────────────────────────────────

CARBON_MODIFIER: dict[str, float] = {
    "renewable_verified": 1.15,
    "renewable_claimed":  1.05,
    "unknown":            1.00,
    "high_carbon":        0.90,
}


def apply_stewardship_modifier(base_score: float, energy_tag: str) -> float:
    """
    Apply P5 Stewardship carbon-aware weight modifier.

    Miners declaring verified renewable energy receive a 15% boost.
    High-carbon miners receive a 10% penalty.
    """
    modifier = CARBON_MODIFIER.get(energy_tag, 1.00)
    return round(min(base_score * modifier, 1.0), 6)


# ── Weight normalization ────────────────────────────────────────────────────

def normalize_weights(weights: list[float]) -> list[float]:
    """
    Normalize a list of scores to sum to 1.0 for Yuma Consensus submission.

    If all scores are zero, returns uniform weights.
    """
    total = sum(weights)
    if total == 0:
        return [1.0 / len(weights)] * len(weights)
    return [w / total for w in weights]
