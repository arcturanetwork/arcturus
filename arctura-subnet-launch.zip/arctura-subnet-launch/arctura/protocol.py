"""
arctura/protocol.py

ArcturaSynapse — the mandate request and attestation response format
for the Arctura Bittensor subnet.

Validators send mandates to miners.
Miners return attestation proofs.
"""

import bittensor as bt
from typing import Optional


class ArcturaSynapse(bt.Synapse):
    """
    The core protocol object for the Arctura subnet.

    Mandate fields are set by the validator and sent to the miner.
    Attestation fields are set by the miner and returned to the validator.

    Aligns to Arctura's Five Primitives:
        P1 Sovereignty  — mandate_id uniquely identifies the mandate owner
        P2 Coherence    — deadline_block enforces forward-only ordering
        P3 Attestation  — attestation_hash + merkle_proof are the verifiable proof
        P4 Resonance    — confidence drives Resonance BFT weight-setting
        P5 Stewardship  — energy_tag enables carbon-aware scoring modifier
    """

    # ── Mandate fields (validator → miner) ─────────────────────────────────

    mandate_id: str = ""
    """Unique identifier for this mandate. Format: uuid4 string."""

    mandate_type: str = ""
    """Category of work. Examples: 'compute', 'data', 'inference', 'retrieval'."""

    mandate_payload: dict = {}
    """Task parameters. Schema varies by mandate_type."""

    deadline_block: int = 0
    """Block number by which the miner must respond. Responses after this block
    receive a latency penalty in Resonance BFT scoring."""

    # ── Attestation fields (miner → validator) ──────────────────────────────

    attestation_hash: Optional[str] = None
    """SHA-256 hash of the execution output. This is the primary P3 signal.
    Must be deterministically reproducible from the execution_trace."""

    merkle_proof: Optional[list] = None
    """List of Merkle proof nodes anchoring the attestation_hash to a root.
    Format: [{'hash': str, 'direction': 'left'|'right'}, ...]"""

    execution_trace: Optional[dict] = None
    """Metadata proving the work was performed. Minimum fields:
    {
        'ts': int,           # Unix timestamp of execution
        'duration_ms': int,  # Execution time in milliseconds
        'steps': list,       # List of completed execution steps
        'output_size': int,  # Byte size of output
    }"""

    confidence: float = 0.0
    """Miner's self-reported confidence in the attestation (0.0–1.0).
    Used in Resonance BFT calibration scoring. Historically inaccurate
    confidence scores are penalized in validator weight-setting."""

    energy_tag: str = "unknown"
    """Energy provenance declaration for P5 Stewardship scoring.
    Valid values: 'renewable_verified', 'renewable_claimed', 'unknown', 'high_carbon'
    Validators apply a weight modifier based on this field."""

    # ── Computed fields (set by validator post-scoring) ─────────────────────

    resonance_score: Optional[float] = None
    """Final Resonance BFT score assigned by the validator (0.0–1.0).
    Not set by miners — populated by the validator after scoring."""
