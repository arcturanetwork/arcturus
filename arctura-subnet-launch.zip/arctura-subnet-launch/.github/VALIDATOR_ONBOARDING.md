---
name: Validator onboarding
about: I want to validate the Arctura subnet
title: "[VALIDATOR] "
labels: validator
---

**Validator hotkey (ss58 address):**

**Current subnets you validate:**

**Infrastructure:**
- Server location:
- Stake amount (approximate):

**Questions or blockers:**
