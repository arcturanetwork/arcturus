"""
neurons/validator.py

Arctura subnet validator — scores miner attestations using Resonance BFT
and sets weights via Yuma Consensus.

Phase 01 implementation: attestation validity + completeness + latency + calibration.
Phase 02 will add full BFT peer message-passing between validators.
"""

import time
import argparse
import bittensor as bt
import torch

from arctura.protocol import ArcturaSynapse
from arctura.incentive import score_response, apply_stewardship_modifier, normalize_weights


class ArcturaValidator:
    """
    Arctura subnet validator.

    Lifecycle each tempo period:
        1. Query all registered miners with a mandate synapse
        2. Score each response using Resonance BFT (attestation quality)
        3. Apply P5 Stewardship modifier for energy-aware weighting
        4. Normalize scores and set weights on-chain via Yuma Consensus
    """

    def __init__(self, config=None):
        self.config = config or self._get_config()
        bt.logging(config=self.config, logging_dir=self.config.full_path)

        self.wallet = bt.wallet(config=self.config)
        self.subtensor = bt.subtensor(config=self.config)
        self.dendrite = bt.dendrite(wallet=self.wallet)
        self.metagraph = self.subtensor.metagraph(self.config.netuid)

        # Track historical confidence accuracy per miner hotkey
        self.confidence_history: dict[str, list[float]] = {}

        bt.logging.info(
            f"Arctura validator initialized | "
            f"wallet: {self.wallet} | "
            f"netuid: {self.config.netuid}"
        )

    @staticmethod
    def _get_config():
        parser = argparse.ArgumentParser()
        bt.subtensor.add_args(parser)
        bt.logging.add_args(parser)
        bt.wallet.add_args(parser)
        parser.add_argument("--netuid", type=int, default=1)
        parser.add_argument("--timeout", type=float, default=30.0)
        config = bt.config(parser)
        config.full_path = f"~/.bittensor/validators/{config.wallet.name}/{config.wallet.hotkey}/netuid{config.netuid}/validator"
        return config

    # ── Mandate generation ─────────────────────────────────────────────────

    def _build_mandate(self) -> ArcturaSynapse:
        """
        Build the synapse sent to miners this tempo period.
        In production: pull from the mandate registry.
        Stub: generates a generic compute mandate.
        """
        import uuid
        return ArcturaSynapse(
            mandate_id=str(uuid.uuid4()),
            mandate_type="compute",
            mandate_payload={"task": "attestation_test", "block": self.metagraph.block.item()},
            deadline_block=self.metagraph.block.item() + 10,
        )

    # ── Scoring ────────────────────────────────────────────────────────────

    def _score_responses(
        self,
        synapses: list[ArcturaSynapse],
        uids: list[int],
        request_block: int,
    ) -> dict[int, float]:
        """
        Score all miner responses using Resonance BFT dimensions:
            40% — attestation validity (Merkle proof check)
            30% — execution completeness (trace coverage)
            20% — latency (response within deadline)
            10% — confidence calibration (historical accuracy)
        """
        scores = {}

        for uid, synapse in zip(uids, synapses):
            hotkey = self.metagraph.hotkeys[uid]

            if synapse is None or synapse.attestation_hash is None:
                bt.logging.warning(f"No response from uid {uid}")
                scores[uid] = 0.0
                continue

            calibration = self._get_calibration(hotkey)
            base_score = score_response(
                synapse=synapse,
                request_block=request_block,
                calibration=calibration,
            )

            # P5 Stewardship modifier
            final_score = apply_stewardship_modifier(base_score, synapse.energy_tag)

            # Annotate the synapse with the Resonance score
            synapse.resonance_score = final_score
            scores[uid] = final_score

            # Update confidence calibration history
            self._update_calibration(hotkey, synapse.confidence, final_score)

            bt.logging.debug(
                f"uid {uid} scored | "
                f"base: {base_score:.3f} | "
                f"stewardship: {synapse.energy_tag} | "
                f"final: {final_score:.3f}"
            )

        return scores

    def _get_calibration(self, hotkey: str) -> float:
        history = self.confidence_history.get(hotkey, [])
        if not history:
            return 0.5  # neutral calibration for new miners
        return sum(history) / len(history)

    def _update_calibration(self, hotkey: str, confidence: float, actual_score: float):
        """Track how accurate a miner's self-reported confidence is."""
        accuracy = 1.0 - abs(confidence - actual_score)
        if hotkey not in self.confidence_history:
            self.confidence_history[hotkey] = []
        self.confidence_history[hotkey].append(accuracy)
        # Keep last 100 data points
        self.confidence_history[hotkey] = self.confidence_history[hotkey][-100:]

    # ── Weight setting ─────────────────────────────────────────────────────

    def _set_weights(self, scores: dict[int, float]):
        """Normalize scores and submit weights to Yuma Consensus."""
        uids = list(scores.keys())
        raw_weights = [scores[uid] for uid in uids]
        normalized = normalize_weights(raw_weights)

        uid_tensor = torch.tensor(uids, dtype=torch.int64)
        weight_tensor = torch.tensor(normalized, dtype=torch.float32)

        success, message = self.subtensor.set_weights(
            wallet=self.wallet,
            netuid=self.config.netuid,
            uids=uid_tensor,
            weights=weight_tensor,
            wait_for_inclusion=True,
        )

        if success:
            bt.logging.success(
                f"Weights set | {len(uids)} miners | "
                f"top score: {max(normalized):.3f}"
            )
        else:
            bt.logging.error(f"Weight setting failed: {message}")

    # ── Run loop ───────────────────────────────────────────────────────────

    def run(self):
        bt.logging.info(f"Arctura validator live | netuid: {self.config.netuid}")

        while True:
            try:
                self.metagraph.sync(subtensor=self.subtensor)
                request_block = self.metagraph.block.item()

                # Get active miner UIDs (exclude self)
                my_uid = self.metagraph.hotkeys.index(self.wallet.hotkey.ss58_address)
                miner_uids = [
                    uid for uid in range(len(self.metagraph.S))
                    if uid != my_uid
                ]

                if not miner_uids:
                    bt.logging.warning("No miners registered yet.")
                    time.sleep(12)
                    continue

                # Build and send mandate to all miners
                mandate = self._build_mandate()
                axons = [self.metagraph.axons[uid] for uid in miner_uids]

                synapses = self.dendrite.query(
                    axons=axons,
                    synapse=mandate,
                    deserialize=False,
                    timeout=self.config.timeout,
                )

                # Score responses and set weights
                scores = self._score_responses(synapses, miner_uids, request_block)

                if scores:
                    self._set_weights(scores)

                # Wait one tempo period (360 blocks × 12s ≈ 72 min)
                time.sleep(360 * 12)

            except KeyboardInterrupt:
                bt.logging.info("Validator stopped.")
                break
            except Exception as e:
                bt.logging.error(f"Validator loop error: {e}")
                time.sleep(60)


if __name__ == "__main__":
    ArcturaValidator().run()
