"""
neurons/miner.py

Arctura subnet miner — executes attested mandates and returns
Merkle-anchored proofs to validators.

This is a Phase 01 stub implementation. The mandate execution pipeline
(L1 Orchestration through L5 Action Surface) is wired as a passthrough.
Replace the _execute_mandate method with your real L1–L5 logic.
"""

import time
import json
import hashlib
import argparse
import bittensor as bt

from arctura.protocol import ArcturaSynapse
from arctura.utils import build_merkle_proof, get_energy_tag


class ArcturaMiner:
    """
    Arctura subnet miner.

    Lifecycle:
        1. Axon starts and listens for ArcturaSynapse requests from validators
        2. forward() is called for each incoming synapse
        3. Miner executes the mandate through the L1–L5 signal stack
        4. Miner returns an attestation hash, Merkle proof, and execution trace
        5. Validator scores the response using Resonance BFT
    """

    def __init__(self, config=None):
        self.config = config or self._get_config()
        bt.logging(config=self.config, logging_dir=self.config.full_path)

        self.wallet = bt.wallet(config=self.config)
        self.subtensor = bt.subtensor(config=self.config)
        self.metagraph = self.subtensor.metagraph(self.config.netuid)

        self.axon = bt.axon(wallet=self.wallet, config=self.config)
        self.axon.attach(
            forward_fn=self.forward,
            blacklist_fn=self.blacklist,
            priority_fn=self.priority,
        )

        bt.logging.info(
            f"Arctura miner initialized | "
            f"wallet: {self.wallet} | "
            f"netuid: {self.config.netuid}"
        )

    @staticmethod
    def _get_config():
        parser = argparse.ArgumentParser()
        bt.subtensor.add_args(parser)
        bt.logging.add_args(parser)
        bt.wallet.add_args(parser)
        bt.axon.add_args(parser)
        parser.add_argument("--netuid", type=int, default=1)
        config = bt.config(parser)
        config.full_path = f"~/.bittensor/miners/{config.wallet.name}/{config.wallet.hotkey}/netuid{config.netuid}/miner"
        return config

    # ── Core forward function ───────────────────────────────────────────────

    def forward(self, synapse: ArcturaSynapse) -> ArcturaSynapse:
        """
        Receive a mandate from a validator and return an attestation.

        This is the critical path. Every synapse must return:
            - attestation_hash: cryptographic proof of execution output
            - merkle_proof: list of proof nodes anchoring the hash
            - execution_trace: metadata proving work was done
            - confidence: self-reported confidence (be accurate — calibration is scored)
            - energy_tag: energy provenance for P5 Stewardship scoring
        """
        bt.logging.info(f"Mandate received | id: {synapse.mandate_id} | type: {synapse.mandate_type}")

        start_time = time.time()

        try:
            # ── Execute mandate through L1–L5 pipeline ──────────────────────
            # STUB: Replace this with real mandate execution logic.
            # In production, this routes through:
            #   L1 Orchestration → L2 Sandbox → L3 Cognitive Mesh → L4 Memory → L5 Action
            output = self._execute_mandate(synapse.mandate_type, synapse.mandate_payload)

            duration_ms = int((time.time() - start_time) * 1000)

            # ── Build attestation ────────────────────────────────────────────
            output_str = json.dumps(output, sort_keys=True)
            output_bytes = output_str.encode("utf-8")

            synapse.attestation_hash = hashlib.sha256(output_bytes).hexdigest()
            synapse.merkle_proof = build_merkle_proof(synapse.attestation_hash)
            synapse.execution_trace = {
                "ts": int(time.time()),
                "duration_ms": duration_ms,
                "steps": output.get("steps_completed", []),
                "output_size": len(output_bytes),
                "mandate_id": synapse.mandate_id,
            }
            synapse.confidence = output.get("confidence", 0.75)
            synapse.energy_tag = get_energy_tag()

            bt.logging.success(
                f"Mandate attested | id: {synapse.mandate_id} | "
                f"hash: {synapse.attestation_hash[:16]}... | "
                f"{duration_ms}ms"
            )

        except Exception as e:
            bt.logging.error(f"Mandate execution failed | id: {synapse.mandate_id} | {e}")
            synapse.attestation_hash = None
            synapse.confidence = 0.0

        return synapse

    def _execute_mandate(self, mandate_type: str, payload: dict) -> dict:
        """
        STUB: Execute a mandate through the Arctura signal stack.

        Replace this method with your real L1–L5 pipeline.
        Must return a dict with at minimum:
            - 'steps_completed': list of step identifiers
            - 'confidence': float 0.0–1.0
            - Any output data specific to the mandate_type
        """
        # Stub output — replace with real execution
        return {
            "mandate_type": mandate_type,
            "status": "complete",
            "steps_completed": ["l1_routed", "l2_sandboxed", "l5_executed"],
            "confidence": 0.80,
            "payload_echo": payload,
        }

    # ── Axon middleware ─────────────────────────────────────────────────────

    def blacklist(self, synapse: ArcturaSynapse) -> tuple[bool, str]:
        """Reject requests from unregistered validators."""
        if synapse.dendrite.hotkey not in self.metagraph.hotkeys:
            return True, "Unregistered hotkey"
        return False, ""

    def priority(self, synapse: ArcturaSynapse) -> float:
        """Priority proportional to validator stake."""
        try:
            uid = self.metagraph.hotkeys.index(synapse.dendrite.hotkey)
            return float(self.metagraph.S[uid])
        except ValueError:
            return 0.0

    # ── Run loop ─────────────────────────────────────────────────────────────

    def run(self):
        self.axon.start()
        self.axon.serve(netuid=self.config.netuid, subtensor=self.subtensor)

        bt.logging.info(
            f"Arctura miner live | "
            f"axon: {self.axon} | "
            f"netuid: {self.config.netuid}"
        )

        step = 0
        while True:
            try:
                if step % 5 == 0:
                    self.metagraph.sync(subtensor=self.subtensor)
                    bt.logging.info(f"Metagraph synced | block: {self.metagraph.block.item()}")
                step += 1
                time.sleep(12)
            except KeyboardInterrupt:
                self.axon.stop()
                bt.logging.info("Miner stopped.")
                break


if __name__ == "__main__":
    ArcturaMiner().run()
