# Arctura Subnet Launch Kit

> **Launch [arctura.network](https://arctura.network) as a registered Bittensor subnet.**  
> Everything you need: wallet setup, registration commands, incentive architecture, agent training, and go/no-go checklists.

---

## What is this?

Arctura is a high-frequency decentralized subnet for autonomous resource management. It coordinates verifiable agent action across Earth-bound nodes using a six-layer signal stack and Byzantine-fault-tolerant consensus — **Resonance BFT**.

This repository is the operational home for getting Arctura registered on Bittensor mainnet (Finney) and running as a tokenized agent on creator.bid.

---

## Quick Start

```bash
# 1. Clone this repo
git clone https://github.com/virtualmase/arctura-subnet-launch
cd arctura-subnet-launch

# 2. Check live TAO burn cost before anything else
btcli subnet burn_cost --subtensor.network finney

# 3. Create your three wallets
btcli wallet new_coldkey --wallet.name owner
btcli wallet new_hotkey --wallet.name owner --hotkey default

btcli wallet new_coldkey --wallet.name validator
btcli wallet new_hotkey --wallet.name validator --hotkey default

btcli wallet new_coldkey --wallet.name miner
btcli wallet new_hotkey --wallet.name miner --hotkey default

# 4. Register the subnet (burns TAO)
btcli subnet create --wallet.name owner --subtensor.network finney

# 5. Register neurons (replace N with your netuid)
btcli subnet recycle_register --netuid N --wallet.name validator --subtensor.network finney
btcli subnet recycle_register --netuid N --wallet.name miner --subtensor.network finney
```

---

## Repository Structure

```
arctura-subnet-launch/
├── README.md                      ← You are here
│
├── docs/
│   ├── LAUNCH_PHASES.md           ← Phase 0–4 activation protocol
│   ├── WALLET_SETUP.md            ← Three-wallet architecture
│   ├── INCENTIVE_DESIGN.md        ← Resonance BFT scoring logic
│   ├── VALIDATOR_RECRUITMENT.md   ← How to get validators before mainnet
│   ├── CREATOR_BID_GUIDE.md       ← Tokenizing Arctura as an agent
│   └── GO_NO_GO_CHECKLIST.md      ← Mainnet registration checklist
│
├── neurons/
│   ├── miner.py                   ← Mandate execution + attestation
│   └── validator.py               ← Resonance BFT scoring + weight-setting
│
├── arctura/
│   ├── protocol.py                ← ArcturaSynapse definition
│   ├── incentive.py               ← Attestation quality scoring
│   └── utils.py                   ← Merkle proof helpers
│
├── scripts/
│   ├── start_miner.sh             ← Launch miner on testnet/mainnet
│   ├── start_validator.sh         ← Launch validator
│   └── check_metagraph.sh         ← Verify subnet state
│
└── agent/
    └── arctura-subnet-agent.html  ← AI-powered subnet launch agent (Claude)
```

---

## The Five Primitives

| # | Name | What it means |
|---|------|---------------|
| P1 | **Sovereignty** | Every node owns its mandate. Authority flows through the chain, not from it. |
| P2 | **Coherence** | Byzantine partitions resolve to a single forward-only state. No reorgs. |
| P3 | **Attestation** | Every action emits a Merkle-anchored proof readable on or off-chain. |
| P4 | **Resonance** | BFT cadence adapts to network coherence — consensus is in-tune, not just safe and live. |
| P5 | **Stewardship** | Carbon-aware scheduling. Node weight reflects energy provenance, not only stake. |

---

## The Six-Layer Signal Stack

```
L0  Intent          Human and agent goals as attested mandates
L1  Orchestration   Mandate routing, retry, saga coordination
L2  Sandbox         Capability-scoped, deterministic, replayable execution
L3  Cognitive Mesh  Multi-agent reasoning with pluggable models
L4  Memory Fabric   Vector + relational + ledger memory with attested provenance
L5  Action Surface  Tool, MCP, A2A, and ACP bindings
```

**Bittensor mapping:**  
`L0 mandate` → Synapse · `L5 action` → Axon endpoint · `P3 attestation` → Miner response payload · `Resonance scoring` → Validator weight logic

---

## Launch Phases

| Phase | Name | Status |
|-------|------|--------|
| 0 | Capital & Wallets | **Complete this first** |
| 1 | Local Chain | Development |
| 2 | Testnet | Validation |
| 3 | Mainnet Registration | Requires Phase 0–2 complete |
| 4 | Emission On | 7 days post-registration |

→ See [`docs/LAUNCH_PHASES.md`](docs/LAUNCH_PHASES.md) for full detail.

---

## Subnet Agent

An AI-powered launch intelligence tool lives at [`agent/arctura-subnet-agent.html`](agent/arctura-subnet-agent.html).

Open it in any browser. It uses Claude to answer every question about:
- Live TAO burn cost
- Wallet setup and btcli commands
- Incentive mechanism design
- Resonance BFT validator scoring
- Testnet vs mainnet workflow
- Validator recruitment
- Creator.bid tokenization

No server required. Runs entirely client-side.

---

## Capital Requirements

| Item | Amount |
|------|--------|
| Subnet registration (burn) | Dynamic — check `btcli subnet burn_cost` |
| Validator recycle_register | ~0.1–1 TAO |
| Miner recycle_register | ~0.1–1 TAO |
| Recommended liquid buffer | ≥ 100 TAO total |
| Server runway (30 days) | Budget separately |

> Always check [taostats.io/subnets](https://taostats.io/subnets) for live burn cost immediately before registering. The cost doubles on each new subnet registration and linearly decays — it changes daily.

---

## Key Resources

| Resource | Link |
|----------|------|
| Arctura Network | [arctura.network](https://arctura.network) |
| Bittensor Docs | [docs.bittensor.com](https://docs.bittensor.com) |
| Live Burn Cost | [taostats.io/subnets](https://taostats.io/subnets) |
| Bittensor Discord | [discord.gg/bittensor](https://discord.gg/bittensor) |
| Creator.bid | [creator.bid/agents](https://creator.bid/agents) |
| Subnet Template | [github.com/opentensor/bittensor-subnet-template](https://github.com/opentensor/bittensor-subnet-template) |

---

## Contributing

This repository is maintained by the Arctura team. Open an issue to report errors or suggest improvements to the launch documentation.

---

## License

Apache-2.0 · See [LICENSE](LICENSE)
