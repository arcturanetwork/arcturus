# Go / No-Go Checklist — Mainnet Registration

Run this checklist immediately before executing `btcli subnet create` on Finney mainnet.  
Every item must be checked. No exceptions.

---

## Capital

- [ ] Owner coldkey balance confirmed in the last 60 minutes
- [ ] Balance ≥ current burn cost + 20% buffer
  ```bash
  btcli wallet overview --wallet.name owner --subtensor.network finney
  btcli subnet burn_cost --subtensor.network finney
  ```
- [ ] Validator hotkey funded for recycle_register fee (~0.1–1 TAO)
- [ ] Miner hotkey funded for recycle_register fee (~0.1–1 TAO)
- [ ] 30-day server cost budgeted and liquid

---

## Code — Protocol

- [ ] `arctura/protocol.py` — ArcturaSynapse class tested and validated
- [ ] `neurons/miner.py` — returns valid `attestation_hash` on every synapse
- [ ] `neurons/miner.py` — returns valid `merkle_proof` structure
- [ ] `neurons/validator.py` — sets non-zero weights within every tempo period
- [ ] `neurons/validator.py` — Resonance BFT scoring function returns float 0.0–1.0
- [ ] `arctura/incentive.py` — weight normalization tested (sum to 1.0)
- [ ] No uncaught exceptions in any neuron code paths

---

## Code — Testnet Validation

- [ ] Both neurons ran stably on testnet for **≥ 48 hours**
- [ ] Metagraph confirmed correct UIDs on testnet
- [ ] Validator set non-zero weights at least 3 consecutive tempo periods
- [ ] No axon connection errors or timeouts logged
- [ ] At least 1 external validator connected and set weights on testnet

---

## Network

- [ ] Axon ports are open and externally reachable
  - Default miner axon port: `8091`
  - Default validator axon port: `8092`
  - Test: `curl http://YOUR_SERVER_IP:8091/ping`
- [ ] Server uptime monitoring configured (recommended: UptimeRobot or equivalent)
- [ ] At least 1 external validator confirmed for mainnet post-launch
- [ ] Bittensor Discord announcement drafted and ready

---

## Operations

- [ ] Owner coldkey mnemonic stored offline in **≥ 2 separate physical locations**
- [ ] Validator coldkey mnemonic stored offline
- [ ] Miner coldkey mnemonic stored offline
- [ ] No coldkey mnemonics stored in cloud, email, or password manager
- [ ] Server SSH keys rotated and access restricted
- [ ] Auto-restart scripts configured for both neurons (systemd or PM2)
- [ ] Alerting configured on axon uptime

---

## Documentation

- [ ] Subnet README published (this repository)
- [ ] Incentive paper published or in draft
  - What miners do
  - How they're scored
  - Projected validator APY range
- [ ] `docs/VALIDATOR_RECRUITMENT.md` outreach started

---

## Final Checks

- [ ] Burn cost checked in the **last 30 minutes** (it changes — check again right before transacting)
- [ ] All three wallets have correct balances
- [ ] You have the command ready to paste — do not type it fresh under pressure:
  ```bash
  btcli subnet create --wallet.name owner --subtensor.network finney
  ```
- [ ] Someone else has reviewed this checklist with you

---

## After Registration

Immediately after `btcli subnet create` succeeds:

1. **Record your netuid** — it's in the transaction output. Write it down.
2. **Register validator:**
   ```bash
   btcli subnet recycle_register --netuid YOUR_NETUID --wallet.name validator --subtensor.network finney
   ```
3. **Register miner:**
   ```bash
   btcli subnet recycle_register --netuid YOUR_NETUID --wallet.name miner --subtensor.network finney
   ```
4. **Verify metagraph:**
   ```bash
   btcli subnet metagraph --netuid YOUR_NETUID --subtensor.network finney
   ```
5. **Start neurons immediately** — do not let blocks pass without neurons running
6. **Post in Bittensor Discord** — #subnet-owners with your netuid and docs link

---

## Immunity Period

You have **4 months** from registration before your subnet can be deregistered for low emissions.  
Use this window to recruit validators, publish your incentive paper, and reach emission threshold.

**Emissions activate 7 days post-registration.** Get validators setting weights before day 7.
