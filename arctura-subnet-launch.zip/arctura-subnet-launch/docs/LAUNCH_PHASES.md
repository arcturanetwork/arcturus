# Launch Phases

Arctura's mainnet activation follows a four-phase protocol. Each phase has explicit entry criteria — do not skip phases.

---

## Phase 0 — Capital & Wallets

**Objective:** Have the right TAO, the right wallets, and nothing holding you back.

### Entry criteria
- None. Start here.

### Actions

**1. Check live burn cost**
```bash
btcli subnet burn_cost --subtensor.network finney
```
The burn cost is dynamic. It doubles each time a new subnet registers on Bittensor and linearly decays to a floor over time. Check [taostats.io/subnets](https://taostats.io/subnets) for the current rate and trend.

**2. Acquire TAO**
Recommended minimum: **100 TAO liquid** in your owner coldkey before attempting registration. This covers:
- Subnet registration burn
- Validator and miner recycle_register fees
- Unexpected cost spikes between check and transaction

**3. Create three wallets**

Arctura requires three independent wallet pairs:

| Role | Purpose |
|------|---------|
| Owner | Creates subnet, sets hyperparameters, holds TAO |
| Validator | Runs Resonance BFT scoring, sets weights |
| Miner | Executes attested mandates, returns proofs |

```bash
# Owner
btcli wallet new_coldkey --wallet.name owner
btcli wallet new_hotkey --wallet.name owner --hotkey default

# Validator
btcli wallet new_coldkey --wallet.name validator
btcli wallet new_hotkey --wallet.name validator --hotkey default

# Miner
btcli wallet new_coldkey --wallet.name miner
btcli wallet new_hotkey --wallet.name miner --hotkey default
```

**Security rules:**
- Store every coldkey mnemonic offline in at least two physical locations
- Never reuse coldkeys across roles
- Hotkeys run on servers; coldkeys never touch an internet-connected machine after creation

### Exit criteria
- Owner coldkey holds ≥ current burn cost + 20% buffer
- All three wallet pairs created and mnemonics stored offline
- Validator and miner hotkeys funded for recycle_register fees

---

## Phase 1 — Local Chain

**Objective:** Prove the protocol code works before touching real TAO.

### Entry criteria
- Phase 0 complete

### Actions

**1. Clone the subnet template**
```bash
git clone https://github.com/opentensor/bittensor-subnet-template
cd bittensor-subnet-template
pip install -r requirements.txt
```

**2. Build Arctura protocol files**

Copy and adapt the files from this repository:
- `arctura/protocol.py` — ArcturaSynapse definition
- `neurons/miner.py` — mandate execution
- `neurons/validator.py` — Resonance BFT scoring

**3. Run a local subtensor**
```bash
# Install and run local chain (requires Docker)
git clone https://github.com/opentensor/subtensor
cd subtensor
bash scripts/run/subtensor.sh -e local --no-purge
```

**4. Register and test locally**
```bash
# Create subnet on local chain
btcli subnet create --wallet.name owner --subtensor.network local

# Register neurons
btcli subnet recycle_register --netuid 1 --wallet.name validator --subtensor.network local
btcli subnet recycle_register --netuid 1 --wallet.name miner --subtensor.network local

# Start miner
python neurons/miner.py --netuid 1 --subtensor.network local --wallet.name miner

# Start validator
python neurons/validator.py --netuid 1 --subtensor.network local --wallet.name validator
```

### Exit criteria
- Miner returns valid attestation hashes to validator queries
- Validator sets non-zero weights within tempo period
- No exceptions or axon failures over 1 hour of local operation

---

## Phase 2 — Testnet

**Objective:** Validate on Bittensor's public testnet with real network conditions.

### Entry criteria
- Phase 1 complete
- All protocol tests passing

### Actions

**1. Get testnet TAO**

Testnet TAO is free — request from the Bittensor Discord faucet (#testnet-faucet channel) or use:
```bash
# Check faucet availability in Bittensor Discord
# discord.gg/bittensor → #testnet-faucet
```

**2. Register on testnet**
```bash
btcli subnet create --wallet.name owner --subtensor.network test
# Note your netuid from output

btcli subnet recycle_register --netuid N --wallet.name validator --subtensor.network test
btcli subnet recycle_register --netuid N --wallet.name miner --subtensor.network test
```

**3. Run for 48 hours minimum**
```bash
# Terminal 1 — Miner
bash scripts/start_miner.sh --network test --netuid N

# Terminal 2 — Validator
bash scripts/start_validator.sh --network test --netuid N

# Monitor
bash scripts/check_metagraph.sh --network test --netuid N
```

**4. Recruit one external validator on testnet**

Post in Bittensor Discord (#testnet channel) that you're running a testnet subnet and want a validator to test with. This rehearses the mainnet recruitment process.

### Exit criteria
- Both miner and validator stable for 48+ hours on testnet
- Validator is setting non-zero weights
- Metagraph shows correct UIDs and stake
- At least 1 external validator has connected and set weights

---

## Phase 3 — Mainnet Registration

**Objective:** Register the Arctura subnet on Bittensor Finney mainnet and get neurons running.

### Entry criteria
- Phase 2 complete
- Go/no-go checklist passed (see `docs/GO_NO_GO_CHECKLIST.md`)
- Live burn cost confirmed immediately before transacting

### Actions

**1. Final burn cost check**
```bash
btcli subnet burn_cost --subtensor.network finney
```

**2. Register subnet**
```bash
btcli subnet create --wallet.name owner --subtensor.network finney
# Record your netuid — you will use it for everything going forward
```

**3. Register validator and miner**
```bash
btcli subnet recycle_register --netuid N --wallet.name validator --subtensor.network finney
btcli subnet recycle_register --netuid N --wallet.name miner --subtensor.network finney
```

**4. Verify**
```bash
btcli subnet metagraph --netuid N --subtensor.network finney
```

**5. Start neurons**
```bash
bash scripts/start_miner.sh --network finney --netuid N
bash scripts/start_validator.sh --network finney --netuid N
```

### Immunity period
After registration you have a **4-month immunity period** during which your subnet cannot be deregistered for low emission. Use this window aggressively to recruit validators.

### Exit criteria
- Metagraph confirms your UIDs on mainnet
- Miner and validator running without errors
- At least 1 external validator connected

---

## Phase 4 — Emission On

**Objective:** Activate TAO emissions to the Arctura subnet.

### Entry criteria
- Phase 3 complete
- 7 days elapsed since mainnet registration
- External validators are setting weights

### Actions

**1. Enable emissions (7 days post-registration)**

Emissions activate automatically 7 days after subnet creation. Ensure validators are setting weights before this date — Yuma Consensus requires non-owner validators to distribute emissions.

**2. Monitor emission rate**
```bash
btcli subnet metagraph --netuid N --subtensor.network finney
# Check emission column for your subnet
```

**3. Announce on Bittensor Discord**

Post your netuid and subnet docs in #subnet-owners. This drives organic validator discovery.

**4. Publish incentive paper**

A public document explaining:
- What miners do (execute attested mandates)
- How they're scored (Resonance BFT attestation quality)
- Projected validator APY at various stake levels

### Exit criteria
- Subnet receiving TAO emissions
- Multiple external validators setting weights
- Metagraph shows healthy emission distribution

---

## Roadmap Beyond Phase 4

| Phase | Timeline | Focus |
|-------|----------|-------|
| 02 | Q3 2026 | A2A & ACP protocols, cross-subnet attestation, public bridge audit |
| 03 | Q1 2027 | Carbon scheduler, edge node program, Stewardship Index v1 |
| 04 | Q3 2027 | Mandate marketplace, verified-agent registry, public Truth Ledger |
