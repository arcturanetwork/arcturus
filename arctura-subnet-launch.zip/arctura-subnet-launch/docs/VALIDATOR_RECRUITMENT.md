# Validator Recruitment

Validators are the critical path to Arctura receiving TAO emissions. Without external validators setting weights, Yuma Consensus will not distribute emissions to your subnet — even if your miner is performing perfectly.

**Target: 3–5 external validators running before your immunity period ends.**

---

## Why validators matter

Bittensor's Yuma Consensus combines weight-sets from all validators on a subnet. If the only validator setting weights is your own, you have single-point dependency and your emission rate will be low. External validators:

- Increase the weight-set diversity that Yuma Consensus rewards
- Signal to the root network that the subnet has real adoption
- Make your subnet visible on validator dashboards and discovery tools

---

## Recruitment sequence

### 1. Publish your incentive paper (before mainnet)

A document that answers:
- **What do miners do?** (Execute attested mandates — explain the synapse format)
- **How are miners scored?** (Resonance BFT attestation quality — link to `docs/INCENTIVE_DESIGN.md`)
- **What do validators earn?** (TAO proportional to stake + consensus alignment — give projected ranges)
- **What infrastructure do validators need?** (Server specs, port requirements, estimated cost)

Post this as a GitHub Gist, a Mirror post, or a page on arctura.network before registration day.

---

### 2. Bittensor Discord — #subnet-owners

Post a launch announcement the day you register:

```
Arctura Subnet — now live on Finney mainnet

Netuid: [N]
Mandate type: attested agent action (Resonance BFT scoring)
Validator requirements: [specs]
Incentive docs: [link to this repo]

Looking for validators. DM or reply here.
```

Channel: **discord.gg/bittensor → #subnet-owners**

Also post in **#general** and any validator-specific channels.

---

### 3. Taostats visibility

Once your subnet is registered, it appears on [taostats.io/subnets](https://taostats.io/subnets). Active validators browse new subnets here. Make sure your subnet's metadata is complete — name, description, and docs link set via `btcli subnet set` commands:

```bash
btcli sudo set --param name --value "Arctura" --netuid N --wallet.name owner --subtensor.network finney
btcli sudo set --param repo_name --value "arctura-subnet-launch" --netuid N --wallet.name owner --subtensor.network finney
```

---

### 4. Direct validator outreach

Identify validators currently running on 5–15 subnets — they have infrastructure ready and are looking for new yield sources.

Find them on taostats.io → Validators tab. Look for validators with:
- Stake in multiple subnets (they understand diversification)
- Regular weight-setting activity (they're operationally active)
- Public contact (X handle, Discord, or Telegram)

DM template:
```
Hey — launching Arctura subnet (netuid [N]) on Finney.
Attested mandate architecture with Resonance BFT scoring.
Incentive docs: [link]
Validator setup: ~[X] minutes, standard btcli recycle_register.

Would you consider validating? Happy to answer questions.
```

---

### 5. Emission-period coordination

During the 7-day pre-emission window, coordinate with validators to ensure weights are being set before emissions activate. One way:

- Create a private Discord or Telegram channel for Arctura validators
- Share block timing for when weights should be set
- Provide a pre-built `start_validator.sh` script (see `scripts/start_validator.sh`)

---

## What validators need from you

| Need | What to provide |
|------|----------------|
| What do I run? | Link to `neurons/validator.py` and `scripts/start_validator.sh` |
| What are the server specs? | Document in README or a separate VALIDATOR_SETUP.md |
| What ports? | Default axon: 8092 (confirm in your config) |
| How do I register? | `btcli subnet recycle_register --netuid N --wallet.name validator --subtensor.network finney` |
| What will I earn? | Projected APY range from your incentive paper |
| Who do I contact for support? | Your Discord/Telegram/X handle |

---

## Validator server specs (recommended minimums)

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | 4 cores | 8 cores |
| RAM | 8 GB | 16 GB |
| Storage | 50 GB SSD | 100 GB SSD |
| Network | 100 Mbps | 1 Gbps |
| OS | Ubuntu 22.04 | Ubuntu 22.04 |
| Python | 3.10+ | 3.11+ |

---

## Retention

Getting validators is the first step. Keeping them requires:

- **Uptime** — your axon must be consistently reachable
- **Communication** — announce changes to the incentive mechanism in advance
- **Fair scoring** — validators who set accurate weights should see consistent emission alignment
- **Transparency** — publish weekly subnet updates to the Discord or Arctura network site
