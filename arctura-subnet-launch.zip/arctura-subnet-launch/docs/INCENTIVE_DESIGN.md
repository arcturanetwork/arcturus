# Incentive Design — Resonance BFT Scoring

How Arctura validators score miners, set weights, and interact with Bittensor's Yuma Consensus.

---

## Overview

Bittensor subnets define their own incentive mechanism. Arctura's is built on **Resonance BFT** — a scoring model that rewards miners for the quality and verifiability of their attestation proofs, not just throughput.

The core signal: **did the miner prove what it did, correctly and verifiably?**

---

## How Yuma Consensus Works (Bittensor layer)

1. Validators set weight vectors over miner UIDs each tempo period
2. These weight vectors are submitted on-chain
3. Yuma Consensus combines all validator weight-sets into a final emission distribution
4. Miners receive TAO proportional to their consensus-weighted score
5. Validators receive TAO proportional to their stake and alignment with consensus

Arctura plugs into this at step 1: the validator's weight-setting logic is where Resonance BFT lives.

---

## Arctura's Scoring Model

### What miners do

Miners receive a `ArcturaSynapse` from validators containing:
- `mandate_id` — unique identifier
- `mandate_type` — the category of work (e.g., `compute`, `data`, `inference`)
- `mandate_payload` — the actual task parameters
- `deadline_block` — block number by which the response is required

Miners must return:
- `attestation_hash` — SHA-256 (or stronger) hash of the execution output
- `merkle_proof` — list of proof nodes anchoring the attestation to a Merkle root
- `execution_trace` — metadata proving the work was actually performed
- `confidence` — miner's self-reported confidence score (0.0–1.0)

### How validators score responses

Validators score each miner response on four dimensions:

| Dimension | Weight | What it measures |
|-----------|--------|-----------------|
| Attestation validity | 40% | Is the Merkle proof cryptographically valid? |
| Execution completeness | 30% | Does the execution trace cover all mandate steps? |
| Response latency | 20% | Did the miner respond within the deadline block? |
| Confidence calibration | 10% | Is the miner's confidence score historically accurate? |

```python
def score_response(synapse: ArcturaSynapse, ground_truth: dict) -> float:
    score = 0.0

    # Attestation validity (40%)
    if verify_merkle_proof(synapse.attestation_hash, synapse.merkle_proof):
        score += 0.4

    # Execution completeness (30%)
    completeness = check_trace_completeness(synapse.execution_trace, ground_truth)
    score += 0.3 * completeness

    # Latency (20%) — linear decay from deadline
    latency_score = max(0, 1 - (response_block - synapse.deadline_block) / 10)
    score += 0.2 * latency_score

    # Confidence calibration (10%)
    calibration = get_historical_calibration(synapse.axon.hotkey)
    score += 0.1 * calibration

    return score
```

---

## Resonance BFT — the validator coordination layer

Standard Bittensor validators set weights independently. Resonance BFT adds a coordination step: before submitting weights on-chain, validators signal each other's scores and resolve disagreements using BFT agreement.

This matters because:
- It prevents a single validator from being gamed by a miner who only performs for that validator
- It ensures weight-sets reflect network-wide attestation quality, not single-observer bias
- It maintains forward-only state — no validator can revise historical weights

In Phase 01, this is implemented as a lightweight peer comparison step in `validator.py`. Full BFT message-passing is roadmapped for Phase 02.

---

## P5 Stewardship — carbon-aware weight modifier

Arctura validators apply an optional modifier to miner weights based on energy provenance:

```python
CARBON_MODIFIER = {
    "renewable_verified": 1.15,   # +15% weight
    "renewable_claimed":  1.05,   # +5% weight
    "unknown":            1.00,   # no modifier
    "high_carbon":        0.90,   # -10% weight
}

def apply_stewardship_modifier(base_score: float, energy_tag: str) -> float:
    return base_score * CARBON_MODIFIER.get(energy_tag, 1.00)
```

Miners declare energy provenance in their axon metadata. Phase 03 introduces verified carbon attestations via the Stewardship Index.

---

## Setting Weights

Validators set weights every tempo period (default: 360 blocks, ~72 minutes at 12s/block):

```python
import bittensor as bt

def set_weights(self, scores: dict[int, float]):
    uids = list(scores.keys())
    weights = list(scores.values())

    # Normalize weights to sum to 1
    total = sum(weights)
    weights = [w / total for w in weights]

    self.subtensor.set_weights(
        wallet=self.wallet,
        netuid=self.config.netuid,
        uids=uids,
        weights=weights,
        wait_for_inclusion=True,
    )
```

---

## Validator Economics

Validators earn TAO proportional to:
1. Their stake weight in the network
2. Their alignment with the Yuma Consensus outcome

Higher stake = higher weight in consensus = higher emissions. Validators who consistently set weights aligned with network consensus earn more than outliers.

**Projected validator APY** at various stake levels depends on total subnet emissions, which are determined by the Bittensor root network. Publish your incentive paper with projected ranges once your subnet has 30 days of emission history.

---

## Anti-Gaming Properties

| Attack | Mitigation |
|--------|-----------|
| Miner fakes attestation hash | Merkle proof verification fails |
| Miner performs only for one validator | Resonance BFT cross-validator comparison |
| Validator colludes with miner | Yuma Consensus dilutes outlier weight-sets |
| Miner copies another miner's proof | mandate_id is unique per synapse; proofs are payload-specific |
| Miner times out then submits late | Latency scoring penalizes post-deadline responses |
