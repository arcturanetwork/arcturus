#!/bin/bash
# scripts/check_metagraph.sh
# Verify subnet state on testnet or mainnet

NETWORK="${NETWORK:-test}"
NETUID="${NETUID:-1}"

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --network) NETWORK="$2"; shift ;;
        --netuid)  NETUID="$2";  shift ;;
        *) echo "Unknown: $1"; exit 1 ;;
    esac
    shift
done

echo "Arctura subnet metagraph | network: $NETWORK | netuid: $NETUID"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
btcli subnet metagraph --netuid "$NETUID" --subtensor.network "$NETWORK"
