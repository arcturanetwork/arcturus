#!/bin/bash
# scripts/start_miner.sh
# Start the Arctura subnet miner

set -e

NETWORK="${NETWORK:-test}"
NETUID="${NETUID:-1}"
WALLET_NAME="${WALLET_NAME:-miner}"
HOTKEY="${HOTKEY:-default}"
AXON_PORT="${AXON_PORT:-8091}"
LOG_LEVEL="${LOG_LEVEL:-info}"

# Parse flags
while [[ "$#" -gt 0 ]]; do
    case $1 in
        --network) NETWORK="$2"; shift ;;
        --netuid)  NETUID="$2";  shift ;;
        --wallet)  WALLET_NAME="$2"; shift ;;
        *) echo "Unknown parameter: $1"; exit 1 ;;
    esac
    shift
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Arctura Miner"
echo "  Network: $NETWORK | Netuid: $NETUID"
echo "  Wallet:  $WALLET_NAME/$HOTKEY"
echo "  Axon port: $AXON_PORT"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

python neurons/miner.py \
    --netuid "$NETUID" \
    --subtensor.network "$NETWORK" \
    --wallet.name "$WALLET_NAME" \
    --wallet.hotkey "$HOTKEY" \
    --axon.port "$AXON_PORT" \
    --logging.$LOG_LEVEL
