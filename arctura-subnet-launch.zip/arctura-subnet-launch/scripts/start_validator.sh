#!/bin/bash
# scripts/start_validator.sh
# Start the Arctura subnet validator

set -e

NETWORK="${NETWORK:-test}"
NETUID="${NETUID:-1}"
WALLET_NAME="${WALLET_NAME:-validator}"
HOTKEY="${HOTKEY:-default}"
TIMEOUT="${TIMEOUT:-30}"
LOG_LEVEL="${LOG_LEVEL:-info}"

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --network) NETWORK="$2"; shift ;;
        --netuid)  NETUID="$2";  shift ;;
        --wallet)  WALLET_NAME="$2"; shift ;;
        --timeout) TIMEOUT="$2"; shift ;;
        *) echo "Unknown parameter: $1"; exit 1 ;;
    esac
    shift
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Arctura Validator"
echo "  Network: $NETWORK | Netuid: $NETUID"
echo "  Wallet:  $WALLET_NAME/$HOTKEY"
echo "  Timeout: ${TIMEOUT}s"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

python neurons/validator.py \
    --netuid "$NETUID" \
    --subtensor.network "$NETWORK" \
    --wallet.name "$WALLET_NAME" \
    --wallet.hotkey "$HOTKEY" \
    --timeout "$TIMEOUT" \
    --logging.$LOG_LEVEL
